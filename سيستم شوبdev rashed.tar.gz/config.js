
module.exports = {
    token: "MTQwMDg0ODgzMzc3MjI2MTUwNw.GtjrdX.JgHm2Df3VVFD5TKZK2SHFZrWsXh2sPdrlWlpGc",
    prefix: "$",
    welcomeChannel: "1400582660681764873",
    feedbackChannel: "1400582692344696863",
    suggestChannel: "1400582682236289096",
    orderPanelChannel: "1400582642813898813",
    ticketCategory: "1400582438681317527",
    ticketProductRole: "1400581848962433064",
    ticketSupportRole: "1400581883464515666",
    productOrderChannel: "1400582649478647948",
    designOrderChannel: "1407678253875068990",
    softwareOrderChannel: "1407678321873129534"
};