const { 
  Client, GatewayIntentBits, Partials, 
  EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, 
  ModalBuilder, TextInputBuilder, TextInputStyle, SelectMenuBuilder, 
  InteractionType 
} = require("discord.js");

const config = require("./config");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers
  ],
  partials: [Partials.Channel]
});

client.once("ready", () => {
  console.log(`${client.user.tag} is online!`);
});

// ===== الترحيب =====
client.on("guildMemberAdd", async (member) => {
  const channel = member.guild.channels.cache.get(config.welcomeChannel);
  if (!channel) return;

  const embed = new EmbedBuilder()
    .setTitle("مرحبا بك في سيرفر جوردن")
    .setDescription(
      `هنا خريطة السيرفر\n\n` +
      `روم القوانين لتجنب العقوبة (ايدي الروم)\n` +
      `روم الطلب لطلب منتجات (ايدي الروم)\n` +
      `روم التقييم لتقييم البائعين (ايدي الروم)\n` +
      `روم الدعم الفني (ايدي الروم)\n\n` +
      `بالتوفيق عسل`
    )
    .setColor("Green");

  channel.send({ embeds: [embed] });
});

// ===== التذاكر (طلبات + دعم فني) =====
client.on("interactionCreate", async (interaction) => {
  if (interaction.isSelectMenu()) {
    if (interaction.customId === "ticket_menu") {
      const selected = interaction.values[0];
      const category = interaction.guild.channels.cache.get(config.ticketCategory);

      if (!category) return interaction.reply({ content: "فئة التذاكر غير موجودة!", ephemeral: true });

      // إنشاء الروم الجديد للتذكرة
      const ticketChannel = await interaction.guild.channels.create({
        name: `ticket-${interaction.user.username}`,
        type: 0, // Text Channel
        parent: category.id,
        permissionOverwrites: [
          { id: interaction.user.id, allow: ['ViewChannel', 'SendMessages'] },
          { id: interaction.guild.roles.everyone.id, deny: ['ViewChannel'] }
        ]
      });

      // إعداد أزرار التذكرة
      let row;
      if (selected === "product_ticket") {
        row = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId("claim_product")
            .setLabel("استلام التذكرة")
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId("close_ticket")
            .setLabel("اغلاق التذكرة")
            .setStyle(ButtonStyle.Danger),
          new ButtonBuilder()
            .setCustomId("mention_product")
            .setLabel("منشن للبائعين")
            .setStyle(ButtonStyle.Primary)
        );
      } else if (selected === "support_ticket") {
        row = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId("claim_support")
            .setLabel("استلام التذكرة")
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId("close_ticket")
            .setLabel("اغلاق التذكرة")
            .setStyle(ButtonStyle.Danger)
        );
      }

      const embed = new EmbedBuilder()
        .setTitle(`تذكرة: ${selected === "product_ticket" ? "طلب منتج" : "الدعم الفني"}`)
        .setDescription("يرجى انتظار شخص من الفريق للتواصل معك")
        .setColor("Blue");

      await ticketChannel.send({ content: `<@${interaction.user.id}>`, embeds: [embed], components: [row] });
      interaction.reply({ content: `تم إنشاء التذكرة في ${ticketChannel}`, ephemeral: true });
    }
  }

  // ===== التعامل مع أزرار التذكرة =====
  if (interaction.isButton()) {
    if (interaction.customId.startsWith("claim_")) {
      const roleId = interaction.customId.includes("product") ? config.ticketProductRole : config.ticketSupportRole;
      if (!interaction.member.roles.cache.has(roleId)) {
        return interaction.reply({ content: "لا تمتلك الصلاحية!", ephemeral: true });
      }
      await interaction.reply({ content: `تفضل معك ${interaction.user}`, ephemeral: false });
    }

    if (interaction.customId === "close_ticket") {
      await interaction.reply({ content: "سيتم اغلاق التذكرة خلال 5 ثواني", ephemeral: false });
      setTimeout(() => interaction.channel.delete(), 5000);
    }

    if (interaction.customId === "mention_product") {
      await interaction.channel.send({ content: `<@&${config.ticketProductRole}>` });
      await interaction.reply({ content: "تم منشن البائعين", ephemeral: true });
    }
  }

  // ===== الطلبات =====
  if (interaction.isSelectMenu()) {
    if (interaction.customId === "order_menu") {
      const selected = interaction.values[0];
      const modal = new ModalBuilder()
        .setCustomId(`order_modal_${selected}`)
        .setTitle("أرسل طلبك");

      const orderInput = new TextInputBuilder()
        .setCustomId("order_input")
        .setLabel("اكتب طلبك بالتفصيل")
        .setStyle(TextInputStyle.Paragraph)
        .setMinLength(1)
        .setMaxLength(4000)
        .setPlaceholder("اكتب طلبك هنا...");

      modal.addComponents(new ActionRowBuilder().addComponents(orderInput));
      await interaction.showModal(modal);
    }
  }

  if (interaction.type === InteractionType.ModalSubmit) {
    const customId = interaction.customId;
    let targetChannelId, orderType;

    if (customId === "order_modal_product") {
      targetChannelId = config.productOrderChannel;
      orderType = "طلب منتجات";
    } else if (customId === "order_modal_design") {
      targetChannelId = config.designOrderChannel;
      orderType = "طلب تصاميم";
    } else if (customId === "order_modal_software") {
      targetChannelId = config.softwareOrderChannel;
      orderType = "طلب برمجيات";
    } else return;

    const orderContent = interaction.fields.getTextInputValue("order_input");
    const targetChannel = interaction.guild.channels.cache.get(targetChannelId);
    if (!targetChannel) return interaction.reply({ content: "الروم غير موجود!", ephemeral: true });

    const embed = new EmbedBuilder()
      .setTitle(orderType)
      .setDescription(orderContent)
      .addFields({ name: "العضو:", value: `<@${interaction.user.id}>` })
      .setFooter({ text: "شكراً على طلبك" })
      .setColor("Blue");

    await targetChannel.send({ embeds: [embed] });
    await interaction.reply({ content: "تم إرسال طلبك بنجاح!", ephemeral: true });
  }
});

// ===== فيدباك و اقتراحات + أوامر =====
client.on("messageCreate", async (message) => {
  if (message.author.bot) return;
  if (!message.content.startsWith(config.prefix)) return;

  const args = message.content.slice(config.prefix.length).trim().split(/ +/);
  const cmd = args.shift().toLowerCase();

  if (cmd === "say") message.channel.send(args.join(" "));
  else if (cmd === "send") message.author.send(args.join(" "));
  else if (cmd === "embed") {
    const embed = new EmbedBuilder()
      .setDescription(args.join(" "))
      .setColor("Green");
    message.channel.send({ embeds: [embed] });
  }
  else if (cmd === "ban") {
    const member = message.mentions.members.first();
    if (member) member.ban({ reason: args.slice(1).join(" ") });
  }
  else if (cmd === "kick") {
    const member = message.mentions.members.first();
    if (member) member.kick({ reason: args.slice(1).join(" ") });
  }
  else if (cmd === "come") {
    const member = message.mentions.members.first();
    if (member) member.send(`لقد تم استدعائك! روم الاستدعاء: ${message.channel}`).catch(() => {});
  }
  else if (cmd === "help") {
    const helpEmbed = new EmbedBuilder()
      .setTitle("أوامر البوت")
      .setDescription(
        "`say <message>` - ارسال رسالة\n" +
        "`send <message>` - ارسال DM\n" +
        "`embed <message>` - ارسال ايمبيد\n" +
        "`ban <@user>` - حظر عضو\n" +
        "`kick <@user>` - طرد عضو\n" +
        "`come <@user>` - استدعاء عضو\n" +
        "`ticket` - ارسال بانل التذاكر\n" +
        "`talabat` - ارسال بانل الطلبات"
      )
      .setColor("Yellow");
    message.channel.send({ embeds: [helpEmbed] });
  }
  else if (cmd === "ticket") {
    const embed = new EmbedBuilder()
      .setTitle("بانل التذاكر")
      .setDescription("اختر نوع التذكرة من القائمة أدناه")
      .setColor("Blue");

    const select = new ActionRowBuilder().addComponents(
      new SelectMenuBuilder()
        .setCustomId("ticket_menu")
        .setPlaceholder("اختر نوع التذكرة")
        .addOptions([
          { label: "طلب منتج", value: "product_ticket" },
          { label: "الدعم الفني", value: "support_ticket" }
        ])
    );

    message.channel.send({ embeds: [embed], components: [select] });
  }
  else if (cmd === "talabat") {
    if (message.channel.id !== config.orderPanelChannel) {
      return message.reply("❌ لا يمكنك استخدام هذا الأمر هنا!");
    }

    const embed = new EmbedBuilder()
      .setTitle("بانل الطلبات")
      .setDescription(
        "قوانين الطلبات:\n" +
        "1- ممنوع طلب منتجات 18+\n" +
        "2- ممنوع طلب أعضاء أو بارتنر\n" +
        "3- ممنوع طلب طرق نيترو وكريديت\n" +
        "4- ممنوع طلب أشياء في أماكن خطأ مثل: (تطلب نيترو في روم برمجيات أو تصاميم)\n" +
        "5- ممنوع بيع أي شيء"
      )
      .setColor("Green");

    const select = new ActionRowBuilder().addComponents(
      new SelectMenuBuilder()
        .setCustomId("order_menu")
        .setPlaceholder("اختر نوع طلبك")
        .addOptions([
          { label: "طلب منتجات", value: "product" },
          { label: "طلب تصاميم", value: "design" },
          { label: "طلب برمجيات", value: "software" }
        ])
    );

    await message.channel.send({ embeds: [embed], components: [select] });
  }
});

client.login(config.token);
